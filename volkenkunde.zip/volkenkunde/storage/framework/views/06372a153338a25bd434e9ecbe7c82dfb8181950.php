<?php $__env->startSection('page_name'); ?>
    <h1><?php echo e($page); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    Welcome <?php echo e($page); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('feed'); ?>
    Feed
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.standardLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>