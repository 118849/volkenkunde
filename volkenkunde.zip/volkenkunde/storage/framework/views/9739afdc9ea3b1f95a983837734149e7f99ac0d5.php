<!DOCTYPE html>
<html>
    <head>
        <title>cms</title>
        <link href="<?php echo e(URL::asset('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css')); ?>" rel="stylesheet"/>
        <style>
            html, body{
                width: 100%;
                height: 100%;
            }
        </style>
    </head>
    <body>
        Tentoonstellingen onder constructie

        <script src="<?php echo e(URL::asset('https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(URL::asset('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
    </body>
</html>