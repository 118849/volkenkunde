<!DOCTYPE html>
<html>
    <head>
        <title><?php echo e($page); ?></title>
        <link href="<?php echo e(URL::asset('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css')); ?>" rel="stylesheet"/>
        <link href="css/nav.css" rel="stylesheet"/>
        <link href="css/main.css" rel="stylesheet"/>
        <style>
            html, body{
                width: 100%;
                height: 100%;
            }
        </style>
    </head>
    <body>
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8">
                <nav>
                    <ul class="homelayout_menu">
                        <?php foreach($menu as $x): ?>
                            <?php if($x->page_parent_id == null): ?>
                                <li class="homelayout_menu_li">
                                    <a href="<?php echo e($x->page_route); ?>">
                                        <?php echo e($x->page_name); ?>

                                    </a>
                                    <ul class="homelayout_dropdown_content">
                                        <?php foreach($menu as $y): ?>
                                            <?php if($y->page_parent_id == $x->page_id): ?>
                                                <li>
                                                    <a href="<?php echo e($y->page_route); ?>">
                                                        <?php echo e($y->page_name); ?>

                                                    </a>
                                                </li>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </ul>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </ul>
                </nav>
            </div>
            <div class="col-md-2"></div>
        </div>
        <div class="content_container">
            <div class="row">
                <div class="col-md-12">
                    <!--<?php echo $__env->yieldContent('page_name'); ?>-->
                    <h1><?php echo e($page); ?></h1>
                </div>
                <div class="col-md-3">
                    <ul class="dashed">
                        <?php foreach($second_menu as $x): ?>
                            <li>
                                <a href="<?php echo e($x->page_route); ?>">
                                    <?php echo e($x->page_name); ?>

                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="col-md-6">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
                <div class="col-md-3">
                    <a class="twitter-timeline" data-dnt="true" href="https://twitter.com/volkenkunde" data-widget-id="712996933774741504">Tweets door @volkenkunde</a>
                    <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
                </div>
            </div>
        </div>


        <script src="<?php echo e(URL::asset('https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(URL::asset('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
        <script>
            $('.carousel').carousel({
                interval: 5000,
                pause: 'false'
            })
        </script>
    </body>
</html>
