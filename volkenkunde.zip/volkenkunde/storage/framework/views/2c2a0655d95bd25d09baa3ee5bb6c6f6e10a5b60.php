<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>
        <link href="<?php echo e(URL::asset('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css')); ?>" rel="stylesheet"/>
        <link href="css/nav.css" rel="stylesheet"/>
        <link href="css/main.css" rel="stylesheet"/>
    </head>
    <body>
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8">
                <nav>
                    <ul class="homelayout_menu">
                        <?php foreach($menu as $x): ?>
                            <?php if($x->page_parent_id == null): ?>
                                <li class="homelayout_menu_li">
                                    <a href="<?php echo e($x->page_route); ?>">
                                        <?php echo e($x->page_name); ?>

                                    </a>
                                    <ul class="homelayout_dropdown_content">
                                        <?php foreach($menu as $y): ?>
                                            <?php if($y->page_parent_id == $x->page_id): ?>
                                                <li>
                                                    <a href="<?php echo e($y->page_route); ?>">
                                                        <?php echo e($y->page_name); ?>

                                                    </a>
                                                </li>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </ul>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </ul>
                </nav>
            </div>
            <div class="col-md-2"></div>
        </div>

        <!-- Start Carousel -->
        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
                <?php for($i = 0; $i < $carousel_count; $i++): ?>
                        <!-- Gives first item a class active -->
                <li data-target="#carousel-example-generic" data-slide-to="<?php echo e($i); ?>" class="
                                        <?php if($i == 0): ?>
                        active
                    <?php endif; ?>
                        "></li>
                <?php endfor; ?>
            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner" role="listbox">
                <!-- Moet nog uitvogelen om eerste item een active class te geven -->
                <?php foreach($carousel as $x): ?>
                    <div class="item
                                                <?php if($x->carousel_id == 1): ?>
                            active
                    <?php endif; ?>
                            ">
                        <img src="img/<?php echo e($x->carousel_img); ?>" />
                        <div class="carousel-caption">
                            <p><?php echo e($x->carousel_text); ?></p>
                            <h1><?php echo e($x->carousel_title); ?></h1>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <!-- End Carousel -->
        <div class="content_container">
            <div class="row">
                <div class="col-md-9">
                    Welcome Wouter
                </div>
                <div class="col-md-3">
                    <a class="twitter-timeline" data-dnt="true" href="https://twitter.com/volkenkunde" data-widget-id="712996933774741504">Tweets door @volkenkunde</a>
                    <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
                </div>
            </div>
        </div>


        <script src="<?php echo e(URL::asset('https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(URL::asset('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
        <script>
            $('.carousel').carousel({
                interval: 5000,
                pause: 'false'
            })
        </script>
    </body>
</html>
