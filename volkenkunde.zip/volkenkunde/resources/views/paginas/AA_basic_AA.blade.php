@extends('layouts.standardLayout')

@section('page_name')
    <h1>{{ $page }}</h1>
@endsection

@section('content')
    {!! html_entity_decode($content) !!}
@endsection