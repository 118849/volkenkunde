<!DOCTYPE html>
<html>
    <head>
        <title>cms</title>
        <link href="{{ URL::asset('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css') }}" rel="stylesheet"/>
        <style>
            html, body{
                width: 100%;
                height: 100%;
            }
        </style>
    </head>
    <body>
        <div style="width: 70%; margin-left: 15%;">
            <div class="row">
                <div class="col-md-12">
                    <table style="width:100%;">
                        <tr>
                            <th>Pagina</th>
                            <th>Route</th>
                            <th>Delete</th>
                        </tr>
                        @foreach($pages as $x)
                            <form action="/cms/delpages" method="post">
                                <tr>
                                    <td>{{ $x->page_name }}</td>
                                    <td>{{ $x->page_route }}</td>
                                    <input type="hidden" name="delid" value="{{ $x->page_id }}" checked>
                                    <td><button type="submit" class="btn btn-default">Delete</button></td>
                                </tr>
                            </form>
                        @endforeach
                    </table>
                </div>
            </div>
        </div>

        <script src="{{ URL::asset('https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js') }}" type="text/javascript"></script>
        <script src="{{ URL::asset('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js') }}" type="text/javascript"></script>
    </body>
</html>