<!DOCTYPE html>
<html>
    <head>
        <title>cms</title>
        <link href="{{ URL::asset('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css') }}" rel="stylesheet"/>
        <style>
            html, body{
                width: 100%;
                height: 100%;
            }
        </style>
    </head>
    <body>
        <div style="width: 70%; margin-left: 15%;">
            <div class="row">
                <div class="col-md-12">
                    <form action="/cms/addpages" method="post">

                        <div class="form-group">
                            <label>Pagina:</label>
                            <input type="text" class="form-control" name="page" placeholder="pagina naam">
                        </div>

                        <div class="radio">
                            <label>
                                <input type="radio" name="parentid" value="" checked>
                                Extra menu item
                            </label>
                        </div>
                        @foreach($pages as $x)
                            @if($x->page_parent_id == null)
                                <div class="radio">
                                    <label>
                                        <input type="radio" name="parentid" value="{{ $x->page_id }}">
                                        Onder pagina {{ $x->page_name }}
                                    </label>
                                </div>
                            @endif
                        @endforeach

                        <button type="submit" class="btn btn-default">Submit</button>
                    </form>
                </div>
            </div>
        </div>

        <script src="{{ URL::asset('https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js') }}" type="text/javascript"></script>
        <script src="{{ URL::asset('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js') }}" type="text/javascript"></script>
    </body>
</html>