<!DOCTYPE html>
<html>
    <head>
        <title>cms</title>
        <link href="{{ URL::asset('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css') }}" rel="stylesheet"/>
        <style>
            html, body{
                width: 100%;
                height: 100%;
            }
        </style>
    </head>
    <body>
        </br>
        <div style="width: 70%; margin-left: 15%;">
            <div class="row">
                <div class="col-md-4">
                    <div class="btn-group-vertical" role="group" aria-label="...">
                        @foreach($pages as $x)
                            <button type="button" class="btn btn-default">{{ $x->page_name }}</button>
                        @endforeach
                    </div>
                </div>

                <div class="col-md-8">
                    @foreach($pages as $x)
                        <textarea style="display: none;" name="{{ $x->page_id }}">{{ $x->page_content }}</textarea>
                    @endforeach
                </div>
            </div>
        </div>

        <script src="{{ URL::asset('https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js') }}" type="text/javascript"></script>
        <script src="{{ URL::asset('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js') }}" type="text/javascript"></script>
    </body>
</html>