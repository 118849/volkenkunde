<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use Illuminate\Support\Facades\DB;

class cmsController extends Controller
{
    public function listpages(){
        $pages = DB::table('pages')->get();
        return view('cms.addpages', [
            'pages' => $pages
        ]);
    }

    public function addpage(){
        DB::table('pages')->insert(
            array(
                'page_name' => $_POST['page'],
                'page_route' => $_POST['page'],
                'page_parent_id' => $_POST['parentid']
            )
        );
        return redirect('/cms/addpages');
    }

    public function listdel(){
        $pages = DB::table('pages')->get();
        return view('cms.delpages', [
            'pages' => $pages
        ]);
    }

    public function delpage(){
        DB::table('pages')->where('page_id', '=' ,$_POST['delid'])->delete();
        return redirect('/cms/delpages');
    }

    public function viewedit(){
        $pages = DB::table('pages')->get();
        return view('cms.editpage', [
            'pages'=>$pages
        ]);
    }

    public function postedit(){
        return redirect('/cms/editpages');
    }

    public function listtent(){
        return view('cms.edittentoonstellingen');
    }

    public function addtent(){
        return redirect('/cms/tentoonstellingen');
    }

    public function deltent(){
        return redirect('/cms/tentoonstellingen');
    }
}
