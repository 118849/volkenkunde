<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use Illuminate\Support\Facades\Redirect;

class pageController extends Controller
{
    public function home(){
        $menu = DB::table('pages')->get(); //Used for making the navigation
        $carousel = DB::table('carousels')->get(); //Used for making the carousel
        $carousel_count = DB::table('carousels')->count(); //Used for making the carousel
        return view('paginas.home', [
            'menu'=>$menu,
            'carousel'=>$carousel,
            'carousel_count'=>$carousel_count
        ]);
    }

    public function standard($route){
        $menu = DB::table('pages')->get(); //Used for making the navigation
        $title = DB::table('pages')->where('page_route', $route)->value('page_name');
        $content = DB::table('pages')->where('page_route', $route)->value('page_content');

        if(DB::table('pages')->where('page_route', $route)->value('page_parent_id')){
            $parent = DB::table('pages')->where('page_route', $route)->value('page_parent_id');
        }else{
            $parent = DB::table('pages')->where('page_route', $route)->value('page_id');
        }
        $second_menu = DB::table('pages')->select('page_name','page_route')->where('page_parent_id', $parent)->get();

        return view('paginas.AA_basic_AA', [
            'menu'=>$menu,
            'page'=>$title,
            'second_menu'=>$second_menu,
            'content'=>$content
        ]);
    }
}
