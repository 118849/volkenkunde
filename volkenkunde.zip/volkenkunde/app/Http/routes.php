<?php

/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', 'pageController@home');
Route::get('/{route}', 'pageController@standard');


/*Add/Delete Tentoonstellingen*/
Route::get('/cms/tentoonstellingen', 'cmsController@listtent');
Route::post('/cms/addtentoonstelling', 'cmsController@addtent');
Route::post('/cms/deltentoonstelling', 'cmsController@deltent');


/*Add/Delete/Edit Pages*/
Route::get('/cms/addpages', 'cmsController@listpages');
Route::post('/cms/addpages', 'cmsController@addpage');

Route::get('/cms/delpages', 'cmsController@listdel');
Route::post('/cms/delpages', 'cmsController@delpage');

Route::get('/cms/editpages', 'cmsController@viewedit');
Route::post('/cms/editpages', 'cmsController@postedit');

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/

Route::group(['middleware' => ['web']], function () {
    //
});
